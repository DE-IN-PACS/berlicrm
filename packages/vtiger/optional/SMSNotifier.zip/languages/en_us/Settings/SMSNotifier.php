<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'LBL_ADD_RECORD' => 'New Configuration',
	'SMSNotifier' => 'SMS Provider Configuration',
	'LBL_ADD_CONFIGURATION' => 'New Configuration',
	'LBL_EDIT_CONFIGURATION' => 'Edit Configuration',
	'LBL_SELECT_ONE' => 'Select One',
	'LBL_SERVER_CONFIG' => 'Server Configuration', 
	
	//Fields
	'providertype' => 'Provider',
	'isactive' => 'Active',
	'username' => 'User Name',
	'password' => 'Password',
	'countryprefix' => 'Country Prefix',
	
	//List View
	'Provider' => 'Provider',
	'User Name' => 'User Name',
);

$jsLanguageStrings = array(
	'LBL_DELETE_CONFIRMATION' => 'Are you sure, you want to delete this SMSNotifier Configuration',
	'JS_RECORD_DELETED_SUCCESSFULLY' => 'SMS Provider Deleted Successfully',
	'JS_CONFIGURATION_SAVED' => 'SMS Provider Configurations saved',
);	